BrutalDoom Launcher
Start bdooml.exe to play in Brutal DOOM!

Web page http://octanium-os.blogspot.com/p/brutaldoom-launcher.html